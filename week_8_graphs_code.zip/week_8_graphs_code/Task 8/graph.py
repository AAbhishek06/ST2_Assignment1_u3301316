class Graph:
    def __init__(self, directed=False, weighted=False):
        self.graph = {}
        self.weights = {}
        self.directed = directed
        self.weighted = weighted

    def add_vertex(self, vertex):
        if vertex not in self.graph:
            self.graph[vertex] = []

    def add_edge(self, vertex1, vertex2, weight=0):
        if vertex1 not in self.graph or vertex2 not in self.graph:
            print("One or both vertices not found in graph.")
            return

        self.graph[vertex1].append(vertex2)
        if self.weighted:
            self.weights[(vertex1, vertex2)] = weight

        if not self.directed:
            self.graph[vertex2].append(vertex1)
            if self.weighted:
                self.weights[(vertex2, vertex1)] = weight