# TowerOfHanoi.py

count = 0  # Global variable to count moves

def main():
    global count

    n = int(input("Enter number of disks: "))
    print("The moves are:")

    moveDisks(n, 'A', 'B', 'C')

    print("Number of moves is", count)

def moveDisks(n, fromTower, toTower, auxTower):
    global count

    if n == 1:
        count += 1
        print(f"Move disk 1 from {fromTower} to {toTower}")
        return

    moveDisks(n - 1, fromTower, auxTower, toTower)

    count += 1
    print(f"Move disk {n} from {fromTower} to {toTower}")

    moveDisks(n - 1, auxTower, toTower, fromTower)

main()

# To remove each individual move to match the example given remove the print commands on lines 20 and 26.