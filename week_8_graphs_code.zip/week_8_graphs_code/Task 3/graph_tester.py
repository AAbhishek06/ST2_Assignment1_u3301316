from graph import Graph

print("Undirected graph")
g = Graph()

print("\nAdd vertices A, B, C, D")
for v in ['A', 'B', 'C', 'D']:
    g.add_vertex(v)
g.print_graph()

print("\nAdd edge A-B")
g.add_edge('A', 'B')
g.print_graph()

print("\nAdd edge A-C")
g.add_edge('A', 'C')
g.print_graph()

print("\nAdd edge B-D")
g.add_edge('B', 'D')
g.print_graph()

print("\nRemove edge A-C")
g.remove_edge('A', 'C')
g.print_graph()

print("\nRemove vertex D")
g.remove_vertex('D')
g.print_graph()

print("\nDirected Graph:")
dg = Graph(directed=True)

print("\nAdd vertices A, B, C, D")
for v in ['A', 'B', 'C', 'D']:
    dg.add_vertex(v)
dg.print_graph()

print("\nAdd edge A->B")
dg.add_edge('A', 'B')
dg.print_graph()

print("\nAdd edge B->C")
dg.add_edge('B', 'C')
dg.print_graph()

print("\nAdd edge C->D")
dg.add_edge('C', 'D')
dg.print_graph()

print("\nAdd edge A->D")
dg.add_edge('A', 'D')
dg.print_graph()

print("\nRemove edge B->C")
dg.remove_edge('B', 'C')
dg.print_graph()

print("\nRemove vertex D")
dg.remove_vertex('D')
dg.print_graph()

test_graph = Graph(directed=True)
for v in ['A', 'B', 'C']:
    test_graph.add_vertex(v)

test_graph.add_edge('A', 'B')
test_graph.add_edge('A', 'C')

# Task 2 (BFS)
print("\nBFS starting from vertex 'A':")
visited_bfs = test_graph.bfs('A')
print("Visited vertices in BFS order:", visited_bfs)

# Task 3 (DFS)
print("DFS starting from vertex 'A':")
visited_dfs = test_graph.dfs('A')
print("Visited vertices in DFS order:", visited_dfs)