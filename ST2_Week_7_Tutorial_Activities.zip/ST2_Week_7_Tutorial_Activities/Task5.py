import tkinter as tk
from tkinter import messagebox, ttk
import time
import random
import string
import matplotlib.pyplot as plt


# BST
class Node:
    def __init__(self, name, phone=None):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None


class BST:
    def __init__(self):
        self.root = None

    def insert(self, root, name, phone):
        if root is None:
            return Node(name, phone)
        if name < root.name:
            root.left = self.insert(root.left, name, phone)
        elif name > root.name:
            root.right = self.insert(root.right, name, phone)
        else:
            root.phone = phone
        return root

    def search(self, root, name):
        if root is None or root.name == name:
            return root
        if name < root.name:
            return self.search(root.left, name)
        return self.search(root.right, name)

    def find_min(self, root):
        while root.left:
            root = root.left
        return root

    def delete(self, root, name):
        if root is None:
            return root
        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            if root.right is None:
                return root.left
            temp = self.find_min(root.right)
            root.name, root.phone = temp.name, temp.phone
            root.right = self.delete(root.right, temp.name)
        return root

    def inorder(self, root, res=None):
        if res is None:
            res = []
        if root:
            self.inorder(root.left, res)
            res.append((root.name, root.phone))
            self.inorder(root.right, res)
        return res


# AVL
class AVLNode:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None
        self.height = 1


class AVLTree:
    def __init__(self):
        self.root = None

    def height(self, node):
        return node.height if node else 0

    def balance(self, node):
        return self.height(node.left) - self.height(node.right) if node else 0

    def right_rotate(self, z):
        y = z.left
        t3 = y.right
        y.right = z
        z.left = t3
        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def left_rotate(self, z):
        y = z.right
        t2 = y.left
        y.left = z
        z.right = t2
        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def insert(self, node, name, phone):
        if not node:
            return AVLNode(name, phone)

        if name < node.name:
            node.left = self.insert(node.left, name, phone)
        elif name > node.name:
            node.right = self.insert(node.right, name, phone)
        else:
            node.phone = phone
            return node

        node.height = 1 + max(self.height(node.left), self.height(node.right))
        b = self.balance(node)

        if b > 1 and name < node.left.name:
            return self.right_rotate(node)
        if b < -1 and name > node.right.name:
            return self.left_rotate(node)
        if b > 1 and name > node.left.name:
            node.left = self.left_rotate(node.left)
            return self.right_rotate(node)
        if b < -1 and name < node.right.name:
            node.right = self.right_rotate(node.right)
            return self.left_rotate(node)

        return node

    def min_value_node(self, node):
        while node.left:
            node = node.left
        return node

    def delete(self, root, name):
        if not root:
            return root

        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            if root.right is None:
                return root.left
            temp = self.min_value_node(root.right)
            root.name, root.phone = temp.name, temp.phone
            root.right = self.delete(root.right, temp.name)

        root.height = 1 + max(self.height(root.left), self.height(root.right))
        b = self.balance(root)

        if b > 1 and self.balance(root.left) >= 0:
            return self.right_rotate(root)
        if b > 1 and self.balance(root.left) < 0:
            root.left = self.left_rotate(root.left)
            return self.right_rotate(root)
        if b < -1 and self.balance(root.right) <= 0:
            return self.left_rotate(root)
        if b < -1 and self.balance(root.right) > 0:
            root.right = self.right_rotate(root.right)
            return self.left_rotate(root)

        return root

    def search(self, node, name):
        if node is None or node.name == name:
            return node
        if name < node.name:
            return self.search(node.left, name)
        return self.search(node.right, name)

    def inorder(self, root, res=None):
        if res is None:
            res = []
        if root:
            self.inorder(root.left, res)
            res.append((root.name, root.phone))
            self.inorder(root.right, res)
        return res


# Red Black Tree (RBT)
RED = "RED"
BLACK = "BLACK"


class RBNode:
    def __init__(self, name=None, phone=None, color=RED):
        self.name = name
        self.phone = phone
        self.color = color
        self.left = None
        self.right = None
        self.parent = None


class RedBlackTree:
    def __init__(self):
        self.NIL = RBNode(color=BLACK)
        self.NIL.left = self.NIL
        self.NIL.right = self.NIL
        self.NIL.parent = self.NIL
        self.root = self.NIL

    def search(self, node, name):
        while node != self.NIL and node.name != name:
            node = node.left if name < node.name else node.right
        return None if node == self.NIL else node

    def left_rotate(self, x):
        y = x.right
        x.right = y.left
        if y.left != self.NIL:
            y.left.parent = x
        y.parent = x.parent
        if x.parent == self.NIL:
            self.root = y
        elif x == x.parent.left:
            x.parent.left = y
        else:
            x.parent.right = y
        y.left = x
        x.parent = y

    def right_rotate(self, y):
        x = y.left
        y.left = x.right
        if x.right != self.NIL:
            x.right.parent = y
        x.parent = y.parent
        if y.parent == self.NIL:
            self.root = x
        elif y == y.parent.right:
            y.parent.right = x
        else:
            y.parent.left = x
        x.right = y
        y.parent = x

    def insert(self, name, phone):
        existing = self.search(self.root, name)
        if existing:
            existing.phone = phone
            return

        z = RBNode(name, phone, RED)
        z.left = self.NIL
        z.right = self.NIL
        y = self.NIL
        x = self.root

        while x != self.NIL:
            y = x
            x = x.left if z.name < x.name else x.right

        z.parent = y
        if y == self.NIL:
            self.root = z
        elif z.name < y.name:
            y.left = z
        else:
            y.right = z

        self.fix_insert(z)

    def fix_insert(self, z):
        while z.parent.color == RED:
            if z.parent == z.parent.parent.left:
                y = z.parent.parent.right
                if y.color == RED:
                    z.parent.color = BLACK
                    y.color = BLACK
                    z.parent.parent.color = RED
                    z = z.parent.parent
                else:
                    if z == z.parent.right:
                        z = z.parent
                        self.left_rotate(z)
                    z.parent.color = BLACK
                    z.parent.parent.color = RED
                    self.right_rotate(z.parent.parent)
            else:
                y = z.parent.parent.left
                if y.color == RED:
                    z.parent.color = BLACK
                    y.color = BLACK
                    z.parent.parent.color = RED
                    z = z.parent.parent
                else:
                    if z == z.parent.left:
                        z = z.parent
                        self.right_rotate(z)
                    z.parent.color = BLACK
                    z.parent.parent.color = RED
                    self.left_rotate(z.parent.parent)
        self.root.color = BLACK

    def transplant(self, u, v):
        if u.parent == self.NIL:
            self.root = v
        elif u == u.parent.left:
            u.parent.left = v
        else:
            u.parent.right = v
        v.parent = u.parent

    def minimum(self, node):
        while node.left != self.NIL:
            node = node.left
        return node

    def delete(self, name):
        z = self.search(self.root, name)
        if z is None:
            return

        y = z
        y_original_color = y.color

        if z.left == self.NIL:
            x = z.right
            self.transplant(z, z.right)
        elif z.right == self.NIL:
            x = z.left
            self.transplant(z, z.left)
        else:
            y = self.minimum(z.right)
            y_original_color = y.color
            x = y.right
            if y.parent == z:
                x.parent = y
            else:
                self.transplant(y, y.right)
                y.right = z.right
                y.right.parent = y
            self.transplant(z, y)
            y.left = z.left
            y.left.parent = y
            y.color = z.color

        if y_original_color == BLACK:
            self.fix_delete(x)

    def fix_delete(self, x):
        while x != self.root and x.color == BLACK:
            if x == x.parent.left:
                w = x.parent.right
                if w.color == RED:
                    w.color = BLACK
                    x.parent.color = RED
                    self.left_rotate(x.parent)
                    w = x.parent.right
                if w.left.color == BLACK and w.right.color == BLACK:
                    w.color = RED
                    x = x.parent
                else:
                    if w.right.color == BLACK:
                        w.left.color = BLACK
                        w.color = RED
                        self.right_rotate(w)
                        w = x.parent.right
                    w.color = x.parent.color
                    x.parent.color = BLACK
                    w.right.color = BLACK
                    self.left_rotate(x.parent)
                    x = self.root
            else:
                w = x.parent.left
                if w.color == RED:
                    w.color = BLACK
                    x.parent.color = RED
                    self.right_rotate(x.parent)
                    w = x.parent.left
                if w.right.color == BLACK and w.left.color == BLACK:
                    w.color = RED
                    x = x.parent
                else:
                    if w.left.color == BLACK:
                        w.right.color = BLACK
                        w.color = RED
                        self.left_rotate(w)
                        w = x.parent.left
                    w.color = x.parent.color
                    x.parent.color = BLACK
                    w.left.color = BLACK
                    self.right_rotate(x.parent)
                    x = self.root
        x.color = BLACK

    def inorder(self, node=None, res=None):
        if res is None:
            res = []
        if node is None:
            node = self.root
        if node != self.NIL:
            self.inorder(node.left, res)
            res.append((node.name, node.phone, node.color))
            self.inorder(node.right, res)
        return res

# GUI
class TreeApp:
    def __init__(self, master):
        self.master = master
        self.master.title("Task 5: BST, AVL and Red-Black Trees")

        self.tree_type = tk.StringVar(value="BST")
        self.trees = {"BST": BST(), "AVL": AVLTree(), "RBT": RedBlackTree()}

        top = tk.Frame(master)
        top.pack(pady=10)

        tk.Label(top, text="Tree Type").grid(row=0, column=0, padx=5)
        ttk.Combobox(top, textvariable=self.tree_type, values=["BST", "AVL", "RBT"], state="readonly", width=10).grid(row=0, column=1, padx=5)

        tk.Label(top, text="Name").grid(row=1, column=0, padx=5)
        self.name_entry = tk.Entry(top)
        self.name_entry.grid(row=1, column=1, padx=5)

        tk.Label(top, text="Phone").grid(row=2, column=0, padx=5)
        self.phone_entry = tk.Entry(top)
        self.phone_entry.grid(row=2, column=1, padx=5)

        btns = tk.Frame(master)
        btns.pack(pady=5)

        tk.Button(btns, text="Insert", command=self.insert_contact).grid(row=0, column=0, padx=5)
        tk.Button(btns, text="Search", command=self.search_contact).grid(row=0, column=1, padx=5)
        tk.Button(btns, text="Delete", command=self.delete_contact).grid(row=0, column=2, padx=5)
        tk.Button(btns, text="Show All", command=self.show_all).grid(row=0, column=3, padx=5)
        tk.Button(btns, text="Benchmark", command=self.run_benchmark).grid(row=0, column=5, padx=5)

        self.output = tk.Text(master, height=10, width=65)
        self.output.pack(pady=10)

        self.canvas = tk.Canvas(master, width=900, height=400, bg="white")
        self.canvas.pack(pady=10)

    def current_tree_name(self):
        return self.tree_type.get()

    def current_tree(self):
        return self.trees[self.current_tree_name()]

    def clear_entries(self):
        self.name_entry.delete(0, tk.END)
        self.phone_entry.delete(0, tk.END)

    def tree_insert(self, tree, name, phone):
        if self.current_tree_name() == "RBT":
            tree.insert(name, phone)
        else:
            tree.root = tree.insert(tree.root, name, phone)

    def tree_delete(self, tree, name):
        if self.current_tree_name() == "RBT":
            tree.delete(name)
        else:
            tree.root = tree.delete(tree.root, name)

    def tree_inorder(self, tree):
        return tree.inorder() if self.current_tree_name() == "RBT" else tree.inorder(tree.root)

    def insert_contact(self):
        name = self.name_entry.get().strip()
        phone = self.phone_entry.get().strip()
        if not name or not phone:
            messagebox.showwarning("Input Error", "Enter both name and phone.")
            return

        tree = self.current_tree()
        self.tree_insert(tree, name, phone)
        self.clear_entries()
        self.show_all()
        self.draw_tree()

    def search_contact(self):
        name = self.name_entry.get().strip()
        if not name:
            messagebox.showwarning("Input Error", "Enter a name.")
            return

        tree_name = self.current_tree_name()
        tree = self.current_tree()
        node = tree.search(tree.root, name)

        self.output.delete(1.0, tk.END)
        if node:
            if tree_name == "RBT":
                self.output.insert(tk.END, f"Found: {node.name}, Phone: {node.phone}, Color: {node.color}\n")
            else:
                self.output.insert(tk.END, f"Found: {node.name}, Phone: {node.phone}\n")
        else:
            self.output.insert(tk.END, "Contact not found.\n")

    def delete_contact(self):
        name = self.name_entry.get().strip()
        if not name:
            messagebox.showwarning("Input Error", "Enter a name.")
            return

        tree = self.current_tree()
        self.tree_delete(tree, name)
        self.clear_entries()
        self.show_all()
        self.draw_tree()

    def show_all(self):
        self.output.delete(1.0, tk.END)
        contacts = self.tree_inorder(self.current_tree())

        if not contacts:
            self.output.insert(tk.END, "No contacts found.\n")
            return

        for item in contacts:
            self.output.insert(tk.END, f"{item}\n")

    def draw_tree(self):
        self.canvas.delete("all")
        tree = self.current_tree()
        root = tree.root
        nil = tree.NIL if self.current_tree_name() == "RBT" else None

        if root is None or root == nil:
            return

        self._draw_node(root, 450, 30, 180, nil)

    def _draw_node(self, node, x, y, dx, nil=None):
        if node is None or node == nil:
            return

        r = 20

        if getattr(node, "left", None) and node.left != nil:
            self.canvas.create_line(x, y + r, x - dx, y + 70 - r)
            self._draw_node(node.left, x - dx, y + 70, max(dx // 2, 40), nil)

        if getattr(node, "right", None) and node.right != nil:
            self.canvas.create_line(x, y + r, x + dx, y + 70 - r)
            self._draw_node(node.right, x + dx, y + 70, max(dx // 2, 40), nil)

        if hasattr(node, "color"):
            fill, text_color = ("red" if node.color == RED else "black"), "white"
        elif hasattr(node, "height"):
            fill, text_color = "lightgreen", "black"
        else:
            fill, text_color = "lightblue", "black"

        display_name = node.name if len(node.name) <= 8 else node.name[:8]
        self.canvas.create_oval(x - r, y - r, x + r, y + r, fill=fill)
        self.canvas.create_text(x, y, text=display_name, fill=text_color)

    def bench(self, tree, names, phones, search_names, delete_names, rbt=False):
        start = time.time()
        for i in range(len(names)):
            if rbt:
                tree.insert(names[i], phones[i])
            else:
                tree.root = tree.insert(tree.root, names[i], phones[i])
        insert_t = time.time() - start

        start = time.time()
        found = sum(1 for name in search_names if tree.search(tree.root, name))
        search_t = time.time() - start

        start = time.time()
        for name in delete_names:
            if rbt:
                tree.delete(name)
            else:
                tree.root = tree.delete(tree.root, name)
        delete_t = time.time() - start

        return insert_t, search_t, delete_t, found

    def run_benchmark(self):
        self.output.delete(1.0, tk.END)
        self.output.insert(tk.END, "Running benchmark...\n")
        self.master.update_idletasks()

        n = 5000
        search_fraction = 0.5
        delete_count = 100

        names = [''.join(random.choices(string.ascii_lowercase, k=10)) for _ in range(n)]
        phones = [''.join(random.choices(string.digits, k=10)) for _ in range(n)]
        search_names = random.sample(names, int(n * search_fraction)) + ['notfoundname'] * int(n * (1 - search_fraction))
        delete_names = random.sample(names, delete_count)

        bst_insert, bst_search, bst_delete, found_bst = self.bench(BST(), names, phones, search_names, delete_names)
        avl_insert, avl_search, avl_delete, found_avl = self.bench(AVLTree(), names, phones, search_names, delete_names)
        rbt_insert, rbt_search, rbt_delete, found_rbt = self.bench(RedBlackTree(), names, phones, search_names, delete_names, True)

        summary = (
            f"Benchmark completed with {n} entries\n\n"
            f"Insertions:\n"
            f"  BST: {bst_insert:.6f}s\n"
            f"  AVL: {avl_insert:.6f}s\n"
            f"  RBT: {rbt_insert:.6f}s\n\n"
            f"Searches:\n"
            f"  BST: {bst_search:.6f}s\n"
            f"  AVL: {avl_search:.6f}s\n"
            f"  RBT: {rbt_search:.6f}s\n\n"
            f"Deletions:\n"
            f"  BST: {bst_delete:.6f}s\n"
            f"  AVL: {avl_delete:.6f}s\n"
            f"  RBT: {rbt_delete:.6f}s\n\n"
            f"Found in search:\n"
            f"  BST: {found_bst} / {len(search_names)}\n"
            f"  AVL: {found_avl} / {len(search_names)}\n"
            f"  RBT: {found_rbt} / {len(search_names)}\n"
        )

        self.output.delete(1.0, tk.END)
        self.output.insert(tk.END, summary)

        operations = ["Insert", "Search", "Delete"]
        plt.figure(figsize=(8, 5))
        plt.plot(operations, [bst_insert, bst_search, bst_delete], marker='o', label='BST')
        plt.plot(operations, [avl_insert, avl_search, avl_delete], marker='o', label='AVL')
        plt.plot(operations, [rbt_insert, rbt_search, rbt_delete], marker='o', label='RBT')
        plt.title("BST vs AVL vs Red-Black Tree Benchmark")
        plt.ylabel("Time (seconds)")
        plt.legend()
        plt.tight_layout()
        plt.show()


if __name__ == "__main__":
    root = tk.Tk()
    app = TreeApp(root)
    root.mainloop()