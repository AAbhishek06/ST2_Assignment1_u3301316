class Graph:
    def __init__(self, directed=False, weighted=False):
        self.graph = {}
        self.weights = {}
        self.directed = directed
        self.weighted = weighted

    def add_vertex(self, vertex):
        if vertex not in self.graph:
            self.graph[vertex] = []

    def add_edge(self, vertex1, vertex2, weight=0):
        if vertex1 in self.graph and vertex2 in self.graph:
            if vertex2 not in self.graph[vertex1]:
                self.graph[vertex1].append(vertex2)
                if self.weighted:
                    self.weights[(vertex1, vertex2)] = weight

            if not self.directed:
                if vertex1 not in self.graph[vertex2]:
                    self.graph[vertex2].append(vertex1)
                    if self.weighted:
                        self.weights[(vertex2, vertex1)] = weight
        else:
            print("One or both vertices not found in graph.")

    def remove_edge(self, vertex1, vertex2):
        if vertex1 in self.graph and vertex2 in self.graph[vertex1]:
            self.graph[vertex1].remove(vertex2)
            if self.weighted and (vertex1, vertex2) in self.weights:
                del self.weights[(vertex1, vertex2)]

            if not self.directed and vertex2 in self.graph and vertex1 in self.graph[vertex2]:
                self.graph[vertex2].remove(vertex1)
                if self.weighted and (vertex2, vertex1) in self.weights:
                    del self.weights[(vertex2, vertex1)]
        else:
            print("Edge not present in graph.")

    def remove_vertex(self, vertex):
        if vertex in self.graph:
            # remove all edges pointing to this vertex
            for v in list(self.graph.keys()):
                if vertex in self.graph[v]:
                    self.graph[v].remove(vertex)
                    if self.weighted and (v, vertex) in self.weights:
                        del self.weights[(v, vertex)]

            # remove all weights from this vertex to others
            if self.weighted:
                for nbr in self.graph[vertex]:
                    if (vertex, nbr) in self.weights:
                        del self.weights[(vertex, nbr)]

            del self.graph[vertex]
        else:
            print("Vertex not present in graph.")

    def print_graph(self):
        if not self.graph:
            print("Graph is empty.")
            return

        for vertex in self.graph:
            if len(self.graph[vertex]) == 0:
                print(vertex)
            else:
                if self.weighted:
                    neighbors = []
                    for neighbor in self.graph[vertex]:
                        weight = self.weights.get((vertex, neighbor), 0)
                        neighbors.append(f"{neighbor}({weight})")
                else:
                    neighbors = self.graph[vertex]

                if self.directed:
                    print(f"{vertex} --> {' '.join(neighbors)}")
                else:
                    print(f"{vertex} --- {' '.join(neighbors)}")