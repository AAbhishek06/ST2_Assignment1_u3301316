from graph import Graph

print("Undirected graph")
g = Graph()

print("\nAdd vertices A, B, C, D")
for v in ['A', 'B', 'C', 'D']:
    g.add_vertex(v)
g.print_graph()

print("\nAdd edge A-B")
g.add_edge('A', 'B')
g.print_graph()

print("\nAdd edge A-C")
g.add_edge('A', 'C')
g.print_graph()

print("\nAdd edge B-D")
g.add_edge('B', 'D')
g.print_graph()

print("\nRemove edge A-C")
g.remove_edge('A', 'C')
g.print_graph()

print("\nRemove vertex D")
g.remove_vertex('D')
g.print_graph()


print("\nDirected Graph:")
dg = Graph(directed=True)

print("\nAdd vertices A, B, C, D")
for v in ['A', 'B', 'C', 'D']:
    dg.add_vertex(v)
dg.print_graph()

print("\nAdd edge A->B")
dg.add_edge('A', 'B')
dg.print_graph()

print("\nAdd edge B->C")
dg.add_edge('B', 'C')
dg.print_graph()

print("\nAdd edge C->D")
dg.add_edge('C', 'D')
dg.print_graph()

print("\nAdd edge A->D")
dg.add_edge('A', 'D')
dg.print_graph()

print("\nRemove edge B->C")
dg.remove_edge('B', 'C')
dg.print_graph()

print("\nRemove vertex D")
dg.remove_vertex('D')
dg.print_graph()

# Separate graph for Task 2 and Task 3
test_graph = Graph(directed=True)
for v in ['A', 'B', 'C']:
    test_graph.add_vertex(v)

test_graph.add_edge('A', 'B')
test_graph.add_edge('B', 'C')
test_graph.add_edge('A', 'C')

# Task 2 (BFS)
print("\nBFS starting from vertex 'A':")
visited_bfs = test_graph.bfs('A')
print("Visited vertices in BFS order:", visited_bfs)

# Task 3 (DFS)
print("DFS starting from vertex 'A':")
visited_dfs = test_graph.dfs('A')
print("Visited vertices in DFS order:", visited_dfs)

# Task 4 cycle detection in undirected graphs
cycle_graph = Graph(directed=False)
for v in ['A', 'B', 'C']:
    cycle_graph.add_vertex(v)
cycle_graph.add_edge('A', 'B')
cycle_graph.add_edge('B', 'C')
cycle_graph.add_edge('C', 'A')

print("Does cycle_graph have a cycle? ", cycle_graph.has_undirected_cycle())

acyclic_graph = Graph(directed=False)
for v in ['X', 'Y', 'Z']:
    acyclic_graph.add_vertex(v)
acyclic_graph.add_edge('X', 'Y')
acyclic_graph.add_edge('Y', 'Z')

print("Does acyclic_graph have a cycle? ", acyclic_graph.has_undirected_cycle())

# Task 5 weighted directed graph
wg = Graph(directed=True, weighted=True)
for v in ['A', 'B', 'C']:
    wg.add_vertex(v)

wg.add_edge('A', 'B', weight=15)
wg.add_edge('B', 'C', weight=34)
wg.add_edge('A', 'C', weight=50)

print("Weighted Directed Graph:")
wg.print_graph()