from tkinter import *

class SierpinskiTriangle:
    def __init__(self):
        window = Tk()
        window.title("Sierpinski Triangle")

        self.width = 400
        self.height = 400

        self.canvas = Canvas(window, width=self.width, height=self.height)
        self.canvas.pack()

        frame1 = Frame(window)
        frame1.pack()

        Label(frame1, text="Enter an order: ").pack(side=LEFT)
        self.order = StringVar()
        Entry(frame1, textvariable=self.order, justify=RIGHT).pack(side=LEFT)
        Button(frame1, text="Display Sierpinski Triangle", command=self.display).pack(side=LEFT)

        window.mainloop()

    def display(self):
        order = int(self.order.get())

        self.canvas.delete("line")

        p1 = [self.width / 2, 10]
        p2 = [10, self.height - 10]
        p3 = [self.width - 10, self.height - 10]

        self.display_triangle(order, p1, p2, p3)

    def display_triangle(self, order, p1, p2, p3):
        if order == 0:
            self.draw_line(p1, p2)
            self.draw_line(p2, p3)
            self.draw_line(p3, p1)
        else:
            p12 = self.midpoint(p1, p2)
            p23 = self.midpoint(p2, p3)
            p31 = self.midpoint(p3, p1)

            self.display_triangle(order - 1, p1, p12, p31)
            self.display_triangle(order - 1, p12, p2, p23)
            self.display_triangle(order - 1, p31, p23, p3)

    def draw_line(self, p1, p2):
        self.canvas.create_line(p1[0], p1[1], p2[0], p2[1], tags="line")

    def midpoint(self, p1, p2):
        return [(p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2]

SierpinskiTriangle()