class Graph:
    def __init__(self, directed=False, weighted=False):
        self.graph = {}
        self.weights = {}
        self.directed = directed
        self.weighted = weighted

    def add_vertex(self, vertex):
        if vertex not in self.graph:
            self.graph[vertex] = []

    def add_edge(self, vertex1, vertex2, weight=0):
        if vertex1 not in self.graph or vertex2 not in self.graph:
            print("One or both vertices not found in graph.")
            return

        if vertex2 not in self.graph[vertex1]:
            self.graph[vertex1].append(vertex2)
            if self.weighted:
                self.weights[(vertex1, vertex2)] = weight

        if not self.directed:
            if vertex1 not in self.graph[vertex2]:
                self.graph[vertex2].append(vertex1)
                if self.weighted:
                    self.weights[(vertex2, vertex1)] = weight

    def remove_edge(self, vertex1, vertex2):
        if vertex1 in self.graph and vertex2 in self.graph[vertex1]:
            self.graph[vertex1].remove(vertex2)
            if self.weighted and (vertex1, vertex2) in self.weights:
                del self.weights[(vertex1, vertex2)]

            if not self.directed and vertex1 in self.graph[vertex2]:
                self.graph[vertex2].remove(vertex1)
                if self.weighted and (vertex2, vertex1) in self.weights:
                    del self.weights[(vertex2, vertex1)]
        else:
            print("Edge not present in graph.")

    def remove_vertex(self, vertex):
        if vertex not in self.graph:
            print("Vertex not present in graph.")
            return

        for v in self.graph:
            if vertex in self.graph[v]:
                self.graph[v].remove(vertex)
                if self.weighted and (v, vertex) in self.weights:
                    del self.weights[(v, vertex)]

        if self.weighted:
            for nbr in self.graph[vertex]:
                if (vertex, nbr) in self.weights:
                    del self.weights[(vertex, nbr)]

        del self.graph[vertex]

    def bfs(self, start_vertex):
        if start_vertex not in self.graph:
            return []

        visited = []
        seen = {start_vertex}
        queue = [start_vertex]

        while queue:
            vertex = queue.pop(0)
            visited.append(vertex)

            for neighbor in self.graph[vertex]:
                if neighbor not in seen:
                    seen.add(neighbor)
                    queue.append(neighbor)

        return visited

    def dfs(self, start_vertex):
        if start_vertex not in self.graph:
            return []

        visited = []
        seen = set()
        stack = [start_vertex]

        while stack:
            vertex = stack.pop()
            if vertex not in seen:
                seen.add(vertex)
                visited.append(vertex)

                for neighbor in reversed(self.graph[vertex]):
                    if neighbor not in seen:
                        stack.append(neighbor)

        return visited

    def has_undirected_cycle(self):
        if self.directed:
            return False

        visited = set()

        def cycle_dfs(vertex, parent):
            visited.add(vertex)

            for neighbor in self.graph[vertex]:
                if neighbor not in visited:
                    if cycle_dfs(neighbor, vertex):
                        return True
                elif neighbor != parent:
                    return True

            return False

        for vertex in self.graph:
            if vertex not in visited:
                if cycle_dfs(vertex, None):
                    return True

        return False

    def print_graph(self):
        if not self.graph:
            print("Graph is empty.")
            return

        for vertex in self.graph:
            if not self.graph[vertex]:
                print(vertex)
            else:
                if self.weighted:
                    neighbors = []
                    for neighbor in self.graph[vertex]:
                        weight = self.weights.get((vertex, neighbor), 0)
                        neighbors.append(f"{neighbor}({weight})")
                else:
                    neighbors = self.graph[vertex]

                if self.directed:
                    print(f"{vertex} --> {' '.join(neighbors)}")
                else:
                    print(f"{vertex} --- {' '.join(neighbors)}")